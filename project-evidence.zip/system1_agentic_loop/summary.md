# Run summary — 20261003_090952

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1145** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | escalated |  | - | 2 | 0 | 6379 | 466 | 0.0087 | 5.0 |
| claim_02_stolen_bike | escalated |  | - | 3 | 0 | 9022 | 347 | 0.0108 | 4.7 |
| claim_03_water_damage | escalated |  | - | 2 | 0 | 6096 | 371 | 0.008 | 3.9 |
| claim_04_neighbor_injury | routed | liability | high | 6 | 0 | 21547 | 922 | 0.0262 | 12.4 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 15041 | 1006 | 0.0201 | 10.5 |
| claim_06_low_confidence_escalation | escalated |  | - | 3 | 0 | 9769 | 752 | 0.0135 | 8.8 |
| claim_07_tree_falls_on_car | escalated |  | - | 2 | 0 | 6296 | 470 | 0.0086 | 5.4 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14445 | 851 | 0.0187 | 9.1 |
