# Run summary — 20261003_054046

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1146** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6283 | 449 | 0.0085 | 8.3 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 13940 | 754 | 0.0177 | 8.2 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 6218 | 442 | 0.0084 | 4.6 |
| claim_04_neighbor_injury | incomplete | - | - | 2 | 0 | 6183 | 485 | 0.0086 | 5.7 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14569 | 871 | 0.0189 | 9.2 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9370 | 542 | 0.0121 | 7.2 |
| claim_07_tree_falls_on_car | routed | auto | medium | 5 | 0 | 17894 | 871 | 0.0222 | 11.5 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14124 | 783 | 0.018 | 9.1 |
